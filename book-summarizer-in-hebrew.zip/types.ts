
export interface BookSummary {
  summary: string;
  keyIdeas: string[];
  interpretation: string;
}
